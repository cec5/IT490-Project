<?php
require_once('databaseFunctions.php');
addPlayersIntoDatabase();
?>
