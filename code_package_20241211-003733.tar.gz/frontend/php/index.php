<?php include 'header.php';?>
<body>
    <!-- Content Section -->
    <div class="container mt-5">
        <h1>Soccer Fantasy League</h1>
        <p>This is a simple soccer fantasy webapp, users can create a league, join a league, draft players, manage rosters, and initiate trades with other players</p>
    </div>

    <!-- Bootstrap JS -->
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
