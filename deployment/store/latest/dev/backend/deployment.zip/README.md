# IT490 Soccer Fantasy League Project
This is a webapp that allows users to participate in a fantasy soccer league
Users can create/join a league, where their points will be tracked on a leaderboard
Users can also post messages on a message board in each league they are a member of
